
import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { LayoutDashboard } from 'lucide-react';

const Header = () => {
  const navigate = useNavigate();

  return (
    <motion.header
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-white border-b border-[#E5E5E5] sticky top-0 z-50"
    >
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center justify-between">
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-3 hover:opacity-80 transition-opacity"
          >
            <img 
              src="https://horizons-cdn.hostinger.com/e275722c-fa00-43fb-9260-1ee1b89a46ba/e86844d8ae493331bc85900765bfea7a.png"
              alt="Uno Más Vinhos"
              className="h-16 w-auto -my-2" 
            />
          </button>
          
          <div className="flex items-center gap-6">
            <button onClick={() => navigate('/')} className="text-sm font-medium text-[#1A1A1A] hover:text-[#8B4513] transition-colors">
              Vinhos
            </button>
            <button onClick={() => navigate('/como-escolher')} className="text-sm font-medium text-[#1A1A1A] hover:text-[#8B4513] transition-colors">
              Como Escolher
            </button>
             <button onClick={() => navigate('/dashboard')} className="flex items-center gap-1 text-sm font-medium text-[#1A1A1A] hover:text-[#8B4513] transition-colors">
              <LayoutDashboard className="h-4 w-4" />
              Gestão
            </button>
          </div>
        </div>
      </nav>
    </motion.header>
  );
};

export default Header;
