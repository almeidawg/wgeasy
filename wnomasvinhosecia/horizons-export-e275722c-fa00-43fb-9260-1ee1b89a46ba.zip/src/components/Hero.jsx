import React from 'react';
import { motion } from 'framer-motion';
const Hero = () => {
  return <section className="bg-white border-b border-[#E5E5E5]">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
        <motion.h1 initial={{
        opacity: 0,
        y: 30
      }} animate={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.7
      }} className="text-4xl sm:text-5xl lg:text-6xl font-semibold text-[#1A1A1A] leading-tight mb-6">
          Vinhos escolhidos com critério.
          <br />
          Para beber bem, sem complicação.
        </motion.h1>
        
        <motion.p initial={{
        opacity: 0,
        y: 30
      }} animate={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.7,
        delay: 0.2
      }} className="text-lg text-[#6B6B6B] max-w-2xl mx-auto">Seleção premium de vinhos da Argentina, Chile, Espanha e França. Qualidade excepcional, sem complicação.</motion.p>
      </div>
    </section>;
};
export default Hero;