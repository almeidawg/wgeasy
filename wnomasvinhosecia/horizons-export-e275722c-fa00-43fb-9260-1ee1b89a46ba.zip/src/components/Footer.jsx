
import React from 'react';
import { Mail, Phone, Instagram, Facebook } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Footer = () => {
  const navigate = useNavigate();

  return (
    <footer className="bg-white border-t border-[#E5E5E5] mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <img 
                src="https://horizons-cdn.hostinger.com/e275722c-fa00-43fb-9260-1ee1b89a46ba/e86844d8ae493331bc85900765bfea7a.png"
                alt="Uno Más Logo"
                className="h-12 w-auto"
              />
            </div>
            <p className="text-sm text-[#6B6B6B] leading-relaxed">
              Vinhos escolhidos com critério. Para beber bem, sem complicação.
            </p>
          </div>

          <div>
            <span className="block text-sm font-semibold text-[#1A1A1A] mb-4">Navegação</span>
            <nav className="flex flex-col gap-2">
              <button onClick={() => navigate('/')} className="text-sm text-left text-[#6B6B6B] hover:text-[#8B4513] transition-colors">
                Vinhos
              </button>
              <button onClick={() => navigate('/como-escolher')} className="text-sm text-left text-[#6B6B6B] hover:text-[#8B4513] transition-colors">
                Como Escolher
              </button>
              <button onClick={() => navigate('/')} className="text-sm text-left text-[#6B6B6B] hover:text-[#8B4513] transition-colors">
                Kits & Seleções
              </button>
            </nav>
          </div>

          <div>
            <span className="block text-sm font-semibold text-[#1A1A1A] mb-4">Contato</span>
            <div className="flex flex-col gap-2">
              <a href="mailto:contato@unomas.com.br" className="text-sm text-[#6B6B6B] hover:text-[#8B4513] transition-colors flex items-center gap-2">
                <Mail className="h-4 w-4" />
                contato@unomas.com.br
              </a>
              <a href="tel:+5511999999999" className="text-sm text-[#6B6B6B] hover:text-[#8B4513] transition-colors flex items-center gap-2">
                <Phone className="h-4 w-4" />
                (11) 99999-9999
              </a>
            </div>
          </div>

          <div>
            <span className="block text-sm font-semibold text-[#1A1A1A] mb-4">Redes Sociais</span>
            <div className="flex gap-3">
              <a
                href="#"
                className="w-10 h-10 rounded-full bg-[#F5F5F5] flex items-center justify-center hover:bg-[#8B4513] hover:text-white transition-colors"
              >
                <Instagram className="h-5 w-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 rounded-full bg-[#F5F5F5] flex items-center justify-center hover:bg-[#8B4513] hover:text-white transition-colors"
              >
                <Facebook className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-[#E5E5E5] text-center">
          <p className="text-sm text-[#6B6B6B]">
            © 2025 Uno Más Vinhos. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
