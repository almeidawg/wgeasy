
import React from 'react';
import { motion } from 'framer-motion';
import { UtensilsCrossed } from 'lucide-react';

const Harmonization = ({ wine }) => {
  return (
    <section className="mb-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="bg-white rounded-2xl p-8 border border-[#E5E5E5]"
      >
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-full bg-[#8B451315] flex items-center justify-center">
            <UtensilsCrossed className="h-6 w-6 text-[#8B4513]" />
          </div>
          <h2 className="text-2xl font-semibold text-[#1A1A1A]">Harmonização</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {wine.pairing.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
              className="bg-[#F5F5F5] rounded-xl p-4 hover:bg-[#E5E5E5] transition-colors"
            >
              <span className="text-sm font-medium text-[#1A1A1A]">{item}</span>
            </motion.div>
          ))}
        </div>

        <div className="mt-6 p-4 bg-[#8B451308] rounded-xl">
          <p className="text-sm text-[#6B6B6B] leading-relaxed">
            <span className="font-semibold text-[#1A1A1A]">Dica do sommelier:</span> {wine.sommelierTip}
          </p>
        </div>
      </motion.div>
    </section>
  );
};

export default Harmonization;
