
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Wine, MapPin } from 'lucide-react';

const ProductCard = ({ wine }) => {
  const navigate = useNavigate();

  return (
    <motion.div
      whileHover={{ y: -8 }}
      transition={{ duration: 0.3 }}
      onClick={() => navigate(`/product/${wine.id}`)}
      className="bg-white rounded-2xl overflow-hidden border border-[#E5E5E5] cursor-pointer group"
    >
      <div className="aspect-[3/4] overflow-hidden bg-[#F5F5F5]">
        <img
          src={wine.image}
          alt={wine.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
      </div>
      
      <div className="p-5">
        <div className="flex items-center gap-2 text-xs text-[#8B4513] font-medium mb-2">
          <Wine className="h-3 w-3" />
          <span>{wine.type}</span>
        </div>
        
        <h3 className="text-lg font-semibold text-[#1A1A1A] mb-1 line-clamp-2 group-hover:text-[#8B4513] transition-colors">
          {wine.name}
        </h3>
        
        <div className="flex items-center gap-1 text-sm text-[#6B6B6B] mb-3">
          <MapPin className="h-3 w-3" />
          <span>{wine.region}, {wine.country}</span>
        </div>
        
        <div className="flex items-center justify-between">
          <span className="text-2xl font-semibold text-[#1A1A1A]">
            R$ {wine.price.toFixed(2)}
          </span>
          <span className="text-xs text-[#6B6B6B]">{wine.alcohol}%</span>
        </div>
      </div>
    </motion.div>
  );
};

export default ProductCard;
