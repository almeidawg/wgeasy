
import React from 'react';
import { motion } from 'framer-motion';
import { Droplet, Wine, Flame, Thermometer } from 'lucide-react';

const QuickUnderstanding = ({ wine }) => {
  const features = [
    {
      icon: Wine,
      label: 'Corpo',
      value: wine.body,
      color: '#8B4513'
    },
    {
      icon: Droplet,
      label: 'Acidez',
      value: wine.acidity,
      color: '#6B8E23'
    },
    {
      icon: Flame,
      label: 'Taninos',
      value: wine.tannins,
      color: '#B8860B'
    },
    {
      icon: Thermometer,
      label: 'Temperatura Ideal',
      value: wine.idealTemperature,
      color: '#CD853F'
    }
  ];

  return (
    <section className="mb-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="bg-white rounded-2xl p-8 border border-[#E5E5E5]"
      >
        <h2 className="text-2xl font-semibold text-[#1A1A1A] mb-8">
          Entenda em 10 segundos
        </h2>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <motion.div
              key={feature.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="text-center"
            >
              <div
                className="w-16 h-16 rounded-full mx-auto mb-3 flex items-center justify-center"
                style={{ backgroundColor: `${feature.color}15` }}
              >
                <feature.icon className="h-8 w-8" style={{ color: feature.color }} />
              </div>
              <span className="block text-xs text-[#6B6B6B] mb-1">{feature.label}</span>
              <span className="block text-sm font-semibold text-[#1A1A1A]">
                {feature.value}
              </span>
            </motion.div>
          ))}
        </div>

        <div className="mt-8 pt-8 border-t border-[#E5E5E5]">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
            <div>
              <span className="block text-xs text-[#6B6B6B] mb-1">Teor Alcoólico</span>
              <span className="text-lg font-semibold text-[#1A1A1A]">{wine.alcohol}%</span>
            </div>
            <div>
              <span className="block text-xs text-[#6B6B6B] mb-1">Método de Produção</span>
              <span className="text-lg font-semibold text-[#1A1A1A]">{wine.productionMethod}</span>
            </div>
            <div>
              <span className="block text-xs text-[#6B6B6B] mb-1">Potencial de Guarda</span>
              <span className="text-lg font-semibold text-[#1A1A1A]">{wine.agingPotential}</span>
            </div>
          </div>
        </div>
      </motion.div>
    </section>
  );
};

export default QuickUnderstanding;
