
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { wines } from '@/data/wines';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, TrendingUp, Package, DollarSign } from 'lucide-react';

const DashboardPage = () => {
  // Aggregate Stats
  const totalStock = wines.reduce((acc, w) => acc + w.inventory.qty, 0);
  const totalValue = wines.reduce((acc, w) => acc + (w.inventory.qty * w.financials.baseCost), 0);
  const lowStockCount = wines.filter(w => w.inventory.qty <= w.inventory.minStock).length;
  
  // Simulated Commercial Stats
  const topSellers = [...wines].sort((a, b) => b.salesStats.totalSold - a.salesStats.totalSold).slice(0, 5);

  return (
    <>
      <Helmet>
        <title>Uno Más - Management Dashboard</title>
      </Helmet>

      <div className="min-h-screen bg-[#FAFAFA]">
        <Header />
        
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-8">
            <h1 className="text-3xl font-semibold text-[#1A1A1A]">Dashboard de Gestão</h1>
            <p className="text-[#6B6B6B]">Visão geral de estoque, financeiro e vendas.</p>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Valor em Estoque</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">R$ {totalValue.toLocaleString('pt-BR')}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Total Garrafas</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{totalStock}</div>
              </CardContent>
            </Card>
             <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Alertas de Estoque</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 text-2xl font-bold text-red-600">
                  <AlertTriangle className="h-6 w-6" />
                  {lowStockCount}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Margem Média</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">42%</div>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="inventory" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-8">
              <TabsTrigger value="inventory">Inventário</TabsTrigger>
              <TabsTrigger value="financial">Financeiro</TabsTrigger>
              <TabsTrigger value="commercial">Comercial</TabsTrigger>
            </TabsList>

            <TabsContent value="inventory">
              <Card>
                <CardHeader>
                  <CardTitle>Controle de Estoque</CardTitle>
                  <CardDescription>Visão detalhada do armazenamento horizontal e alertas.</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Produto</TableHead>
                        <TableHead>Localização</TableHead>
                        <TableHead>Fornecedor</TableHead>
                        <TableHead className="text-right">Qtd</TableHead>
                        <TableHead className="text-center">Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {wines.map((wine) => (
                        <TableRow key={wine.id}>
                          <TableCell className="font-medium">{wine.name}</TableCell>
                          <TableCell>{wine.inventory.location}</TableCell>
                          <TableCell>{wine.suppliers[0].name} {wine.suppliers.length > 1 && `(+${wine.suppliers.length - 1})`}</TableCell>
                          <TableCell className="text-right">{wine.inventory.qty}</TableCell>
                          <TableCell className="text-center">
                            {wine.inventory.qty <= wine.inventory.minStock ? (
                              <Badge variant="destructive">Crítico</Badge>
                            ) : (
                              <Badge variant="outline" className="text-green-600 border-green-200 bg-green-50">OK</Badge>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="financial">
              <Card>
                <CardHeader>
                  <CardTitle>Análise Financeira</CardTitle>
                  <CardDescription>Custos, margens e precificação detalhada.</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Produto</TableHead>
                        <TableHead className="text-right">Custo Base</TableHead>
                        <TableHead className="text-right">Custo Real</TableHead>
                        <TableHead className="text-right">Preço Venda</TableHead>
                        <TableHead className="text-right">Margem %</TableHead>
                        <TableHead className="text-right">Lucro Un.</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {wines.map((wine) => (
                        <TableRow key={wine.id}>
                          <TableCell className="font-medium">{wine.name}</TableCell>
                          <TableCell className="text-right">R$ {wine.financials.baseCost.toFixed(2)}</TableCell>
                          <TableCell className="text-right text-muted-foreground">R$ {wine.financials.totalRealCost.toFixed(2)}</TableCell>
                          <TableCell className="text-right font-bold">R$ {wine.price.toFixed(2)}</TableCell>
                          <TableCell className="text-right">{wine.financials.marginPercent}%</TableCell>
                          <TableCell className="text-right text-green-600">
                            R$ {(wine.price - wine.financials.totalRealCost).toFixed(2)}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="commercial">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <Card>
                  <CardHeader>
                    <CardTitle>Top 5 Mais Vendidos</CardTitle>
                  </CardHeader>
                  <CardContent>
                     <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Produto</TableHead>
                          <TableHead className="text-right">Vendas</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {topSellers.map(wine => (
                          <TableRow key={wine.id}>
                            <TableCell>{wine.name}</TableCell>
                            <TableCell className="text-right">{wine.salesStats.totalSold} un.</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>

                <Card>
                   <CardHeader>
                    <CardTitle>Performance de Kits</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                        <span className="font-medium">Kit 1 - Começar Bem</span>
                        <Badge>Alta Procura</Badge>
                      </div>
                      <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                        <span className="font-medium">Kit 2 - Jantar em Casa</span>
                         <Badge variant="secondary">Média</Badge>
                      </div>
                      <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                        <span className="font-medium">Kit 3 - Malbecs da Argentina</span>
                         <Badge>Alta Procura</Badge>
                      </div>
                      <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                        <span className="font-medium">Kit 4 - Noite Especial</span>
                         <Badge variant="outline">Baixa</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>

        </main>
        <Footer />
      </div>
    </>
  );
};

export default DashboardPage;
